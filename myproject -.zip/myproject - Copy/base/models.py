from django.db import models

# Create your models here.
class Article(models.Model): #model
    title = models.CharField(max_length=100) #feids # Title of the article
    content= models.TextField(max_length=100) # Content of the article
    author = models.CharField(max_length=100) # Author of the article
    summary= models.TextField(max_length=500) # Summary of the article
    views_count = models.IntegerField() # Number of views for the article

# ORM -- object relational mapping
# it will convert python code to sql queries
# python manage.py makemigrations
#python manage.py migrate

#CRUD Operations

#3 ways to perform CRUD

# 1) Admin panel 2) shell 3) Django views

# 1. Admin panel
#  step1: Create the superuser--> python manage.py createsuperuser