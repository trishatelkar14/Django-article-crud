from django.shortcuts import render,redirect,get_object_or_404
from .models import Article
# Create your views here.
def home(request):
    if request.method == 'POST':
        title_data = request.POST['title']
        content_data = request.POST['content']
        author_data = request.POST['author']
        summary_data = request.POST['summary']
        views_count_data = request.POST['views_count']
        
        Article.objects.create(title=title_data, content=content_data,
            author=author_data, summary=summary_data,
            views_count=views_count_data)
        
        return redirect('read_article')
        
    return render(request, 'home.html')

#READ
def read_article(request):
    data = Article.objects.all()  # Fetch all articles from the database
    return render(request, 'read_article.html',{'data':data})


def update_article(request,pk):
    data=get_object_or_404(Article, pk=pk)
    if request.method == 'POST':
        data.title = request.POST['title']
        data.content = request.POST['content']
        data.author = request.POST['author']
        data.summary = request.POST['summary']
        data.views_count = request.POST['views_count']
        data.save()
        return redirect('read_article')
    
    return render(request, 'update_article.html', {'data': data})

#DELETE
def delete_article(request, pk):
    data = get_object_or_404(Article, id=pk)
    if request.method == 'POST':
        data.delete()
        return redirect('read_article')
    
    return render(request, 'delete_article.html', {'data': data})