from django.urls import path
from base import views

urlpatterns = [
    path('', views.read_article, name='read_article'),
    path('home/', views.home,name='home'),
    path('update_article/<int:pk>/', views.update_article, name='update_article'),
    path('delete_article/<int:pk>/', views.delete_article, name='delete_article'),
]
