from django.contrib import admin

#step1: Import the Article model
from .models import Article 

#step2: Register the Article model with the admin site

#step3: Create one model admin to display data and register the model

class ArticleAdmin(admin.ModelAdmin):
    list_display=['id', 'title','content', 'author', 'summary', 'views_count']  

admin.site.register(Article, ArticleAdmin)  